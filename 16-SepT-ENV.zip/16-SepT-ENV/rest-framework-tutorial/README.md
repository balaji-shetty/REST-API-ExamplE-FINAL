# REST framework tutorial

Source code for [Official Django REST Framework Tutorial - A Beginners Guide](https://wsvincent.com/official-django-rest-framework-tutorial-beginners-guide/).

Uses Django 2.2, Django REST Framework 3.10, and Pipenv.
